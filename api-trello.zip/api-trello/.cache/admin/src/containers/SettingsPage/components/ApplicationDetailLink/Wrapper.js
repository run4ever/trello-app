import styled from 'styled-components';

const Wrapper = styled.div`
  position: relative;
  margin-bottom: -5px;
  padding: 25px 20px 0 20px;
`;

export default Wrapper;
