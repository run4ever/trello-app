import styled from 'styled-components';

const Img = styled.img`
  height: 40px;
`;

export default Img;
