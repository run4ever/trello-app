import styled from 'styled-components';

// TODO : Temporary baseline alignment
const BaselineAlignment = styled.div`
  padding-top: 3px;
`;

export default BaselineAlignment;
