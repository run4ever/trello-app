import { createContext } from 'react';

const SettingsHeaderSearchContext = createContext({});

export default SettingsHeaderSearchContext;
